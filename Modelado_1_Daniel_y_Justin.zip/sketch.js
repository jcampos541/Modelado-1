let angle, speed, gravity;
let posX, posY;
let velocityX, velocityY;
let startTime;
let launched = false;
let launchButton;

function setup() {
  createCanvas(800, 400);
  angle = createSlider(0, 90, 45);
  angle.position(20, height + 10);
  speed = createSlider(1, 100, 50);
  speed.position(20, height + 40);
  gravity = createSlider(1, 20, 9.8, 0.1);
  gravity.position(20, height + 70);
  resetSimulation();
  
  launchButton = createButton("🚀 Lanzar Proyectil");
  launchButton.position(20, height + 100);
  launchButton.style("background-color", "#ff5733");
  launchButton.style("color", "white");
  launchButton.style("font-size", "16px");
  launchButton.style("padding", "5px 10px");
  launchButton.mousePressed(startSimulation);
}

function resetSimulation() {
  posX = 50;
  posY = height - 50;
  let angleRad = radians(angle.value());
  velocityX = speed.value() * cos(angleRad);
  velocityY = -speed.value() * sin(angleRad);
  launched = false;
}

function startSimulation() {
  startTime = millis();
  resetSimulation();
  launched = true;
}

function draw() {
  background(100, 149, 237); // Color de fondo azul cielo
  fill(0);
  textSize(16);
  text(`Ángulo: ${angle.value()}°`, 20, 20);
  text(`Velocidad: ${speed.value()} m/s`, 20, 40);
  text(`Gravedad: ${gravity.value()} m/s²`, 20, 60);
  text(`Posición X: ${posX.toFixed(2)} px`, 20, 80);
  text(`Posición Y: ${(height - posY).toFixed(2)} px`, 20, 100);
  text(`Velocidad X: ${velocityX.toFixed(2)} m/s`, 20, 120);
  text(`Velocidad Y: ${(velocityY + gravity.value() * ((millis() - startTime) / 1000)).toFixed(2)} m/s`, 20, 140);
  
  if (launched) {
    let t = (millis() - startTime) / 1000;
    posX = 50 + velocityX * t;
    posY = height - 50 + velocityY * t + 0.5 * gravity.value() * t * t;
    
    if (posY >= height - 50) {
      posY = height - 50;
      launched = false;
    }
  }
  
  textSize(20);
  text("🚀", posX, posY);  // Muestra un cohete como proyectil
}
